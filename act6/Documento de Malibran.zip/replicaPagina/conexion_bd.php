<?php
// Este archivo es para compatibilidad, pero ahora usamos config.php
require_once 'config.php';

// Alias de la función conectarDB para compatibilidad
function getConexion() {
    return conectarDB();
}
?>
