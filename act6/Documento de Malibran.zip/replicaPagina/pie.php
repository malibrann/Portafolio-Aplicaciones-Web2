    <footer>
        <p>Join over 500 hundred of the most creative and brilliant minds of art colleges all
            around the world for three days of lectures by world-renowned art scholars and
            artists.
        </p>
        <a href="#">About the Roux Academy</a> | 
        <a href="#">privacy policy</a> | 
        <a href="#">visit our website</a>
    </footer>
</body>
</html>
