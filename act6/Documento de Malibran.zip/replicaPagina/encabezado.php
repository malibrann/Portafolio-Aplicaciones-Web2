<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo url('Pagina.css'); ?>">
    <title><?php echo isset($pageTitle) ? $pageTitle : 'Roux Academy'; ?></title>
</head>
<body>
    <header>
        <img src="<?php echo url('images/ralogo_monogram.png'); ?>" alt="Logo">
        <p>Roux Academy
            <br>
            Art * Media * Design
        </p>

        <div>
            <h2>Roux Academy 2016 Art Conference</h2>
            <p>Join over 500 hundred of the most creative and brilliant minds of art colleges all
around the world for five days of lectures by world-renowned art scholars and
artists, and seven days and nights of gallery exhibits featuring the best in
contemporary art, including painting, sculpture, and more, in the beautiful halls of
Hotel Contempo in the heart of Seattle.</p>
        </div>
    </header>

    <nav>
        <ul>
            <a href="<?php echo url('home'); ?>">Home</a>
            <a href="<?php echo url('artist'); ?>">Artist</a>
            <a href="<?php echo url('schedule'); ?>">Schedule</a>
            <a href="<?php echo url('venue'); ?>">Venue/Travel</a>
            <a href="<?php echo url('register'); ?>">Register</a>
            <?php if (isAuthenticated()): ?>
                <a href="<?php echo url('logout'); ?>">Logout (<?php echo currentUser()['name']; ?>)</a>
            <?php else: ?>
                <a href="<?php echo url('login'); ?>">Login</a>
            <?php endif; ?>
        </ul>
    </nav>

    <section class="banner"></section>
