<?php
require_once 'config.php';

$url = isset($_GET['url']) ? $_GET['url'] : '';
$url = rtrim($url, '/');
$url = filter_var($url, FILTER_SANITIZE_URL);
$url = explode('/', $url);

$page = isset($url[0]) && $url[0] != '' ? $url[0] : 'home';

$validPages = ['home', 'artist', 'schedule', 'venue', 'register', 'login', 'logout', 'register-submit'];

if ($page == 'logout') {
    session_destroy();
    redirect('home');
}

if ($page == 'register-submit' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'controllers/register_controller.php';
    exit();
}

if ($page == 'login' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'controllers/login_controller.php';
    exit();
}

if (!in_array($page, $validPages)) {
    $page = 'home';
}

$viewFile = 'views/' . $page . '.php';

if (file_exists($viewFile)) {
    include $viewFile;
} else {
    include 'views/home.php';
}
?>
