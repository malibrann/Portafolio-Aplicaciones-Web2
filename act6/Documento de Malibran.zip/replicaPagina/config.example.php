<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'roux_academy');

define('BASE_URL', '/AplicacionesWeb/replicaPagina/');
define('BASE_PATH', __DIR__);

session_start();

function conectarDB() {
    $conexion = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if (!$conexion) {
        die("Error de conexión: " . mysqli_connect_error());
    }
    
    mysqli_set_charset($conexion, "utf8");
    return $conexion;
}

function url($path = '') {
    return BASE_URL . $path;
}

function isAuthenticated() {
    return isset($_SESSION['user_id']);
}

function currentUser() {
    if (isAuthenticated()) {
        return [
            'id' => $_SESSION['user_id'],
            'name' => $_SESSION['user_name'],
            'email' => $_SESSION['user_email']
        ];
    }
    return null;
}

function redirect($path) {
    header('Location: ' . url($path));
    exit();
}