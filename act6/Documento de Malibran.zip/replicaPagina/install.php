<?php
/**
 * Script de instalación de la base de datos
 * Ejecuta este archivo UNA SOLA VEZ para crear la base de datos y las tablas
 * 
 * Accede a: http://localhost/AplicacionesWeb/replicaPagina/install.php
 */

$servidor = "localhost";
$usuario = "root";
$contraseña = "";
$bd = "roux_academy";

echo "<h1>Instalador de Base de Datos - Roux Academy</h1>";
echo "<hr>";

// Conectar a MySQL (sin seleccionar BD)
$conexion = mysqli_connect($servidor, $usuario, $contraseña);

if (!$conexion) {
    die("<p style='color: red;'>❌ Error de conexión: " . mysqli_connect_error() . "</p>");
}

echo "<p>✅ Conexión a MySQL exitosa</p>";

// Crear la base de datos
$sql_create_db = "CREATE DATABASE IF NOT EXISTS $bd CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
if (mysqli_query($conexion, $sql_create_db)) {
    echo "<p>✅ Base de datos '$bd' creada o ya existe</p>";
} else {
    echo "<p style='color: red;'>❌ Error al crear base de datos: " . mysqli_error($conexion) . "</p>";
}

// Seleccionar la base de datos
mysqli_select_db($conexion, $bd);

// Crear tabla de usuarios
$sql_create_table = "
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    company VARCHAR(100),
    registration_type VARCHAR(50),
    how_heard VARCHAR(50),
    newsletter TINYINT(1) DEFAULT 0,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
";

if (mysqli_query($conexion, $sql_create_table)) {
    echo "<p>✅ Tabla 'usuarios' creada o ya existe</p>";
} else {
    echo "<p style='color: red;'>❌ Error al crear tabla: " . mysqli_error($conexion) . "</p>";
}

// Verificar si ya existe el usuario demo
$check_demo = "SELECT id FROM usuarios WHERE email = 'demo@example.com'";
$result = mysqli_query($conexion, $check_demo);

if (mysqli_num_rows($result) == 0) {
    // Insertar usuario demo (password: password123)
    $password_hash = password_hash('password123', PASSWORD_DEFAULT);
    $sql_insert_demo = "
    INSERT INTO usuarios (nombre, email, password, company, registration_type) 
    VALUES ('Usuario Demo', 'demo@example.com', '$password_hash', 'Roux Academy', 'Student')
    ";
    
    if (mysqli_query($conexion, $sql_insert_demo)) {
        echo "<p>✅ Usuario demo creado exitosamente</p>";
        echo "<div style='background: #e3f2fd; padding: 15px; border-left: 4px solid #2196F3; margin: 20px 0;'>";
        echo "<h3>📝 Credenciales de Prueba:</h3>";
        echo "<p><strong>Email:</strong> demo@example.com</p>";
        echo "<p><strong>Password:</strong> password123</p>";
        echo "</div>";
    } else {
        echo "<p style='color: orange;'>⚠️ No se pudo crear el usuario demo: " . mysqli_error($conexion) . "</p>";
    }
} else {
    echo "<p>ℹ️ El usuario demo ya existe</p>";
}

mysqli_close($conexion);

echo "<hr>";
echo "<h2>🎉 ¡Instalación Completada!</h2>";
echo "<p>La base de datos ha sido configurada correctamente.</p>";
echo "<p><strong>⚠️ IMPORTANTE:</strong> Por seguridad, elimina este archivo (install.php) después de la instalación.</p>";
echo "<p><a href='index.php' style='display: inline-block; background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 20px;'>Ir a la aplicación →</a></p>";
?>

<style>
    body {
        font-family: Arial, sans-serif;
        max-width: 800px;
        margin: 50px auto;
        padding: 20px;
        background: #f5f5f5;
    }
    h1 {
        color: #333;
    }
    p {
        line-height: 1.6;
        font-size: 16px;
    }
</style>
