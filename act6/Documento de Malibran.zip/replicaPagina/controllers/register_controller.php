<?php
require_once 'models/User.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = [
        'nombre' => $_POST['fname'] ?? '',
        'email' => $_POST['email'] ?? '',
        'password' => $_POST['password'] ?? '',
        'company' => $_POST['cname'] ?? '',
        'registration_type' => $_POST['regtype'] ?? '',
        'how_heard' => $_POST['howheard'] ?? '',
        'newsletter' => isset($_POST['newsletter']) ? 1 : 0,
        'comment' => $_POST['comment'] ?? ''
    ];
    
    // Validar campos requeridos
    if (empty($data['nombre']) || empty($data['email']) || empty($data['password'])) {
        $_SESSION['error'] = 'Por favor, complete todos los campos requeridos';
        redirect('register');
    }
    
    // Validar email
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = 'Por favor, ingrese un email válido';
        redirect('register');
    }
    
    $user = new User();
    $result = $user->register($data);
    
    if ($result['success']) {
        $_SESSION['success'] = $result['message'] . '. Ahora puede iniciar sesión.';
        redirect('login');
    } else {
        $_SESSION['error'] = $result['message'];
        redirect('register');
    }
}
?>
