<?php
require_once 'models/User.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $_SESSION['error'] = 'Por favor, complete todos los campos';
        redirect('login');
    }
    
    $user = new User();
    $result = $user->login($email, $password);
    
    if ($result['success']) {
        $_SESSION['success'] = $result['message'];
        redirect('home');
    } else {
        $_SESSION['error'] = $result['message'];
        redirect('login');
    }
}
?>
