<?php
class User {
    private $conexion;
    
    public function __construct() {
        $this->conexion = conectarDB();
    }
    
    // Registrar un nuevo usuario
    public function register($data) {
        $nombre = mysqli_real_escape_string($this->conexion, $data['nombre']);
        $email = mysqli_real_escape_string($this->conexion, $data['email']);
        $password = password_hash($data['password'], PASSWORD_DEFAULT);
        $company = mysqli_real_escape_string($this->conexion, $data['company'] ?? '');
        $registration_type = mysqli_real_escape_string($this->conexion, $data['registration_type'] ?? '');
        $how_heard = mysqli_real_escape_string($this->conexion, $data['how_heard'] ?? '');
        $newsletter = isset($data['newsletter']) ? 1 : 0;
        $comment = mysqli_real_escape_string($this->conexion, $data['comment'] ?? '');
        
        // Verificar si el email ya existe
        if ($this->emailExists($email)) {
            return ['success' => false, 'message' => 'El email ya está registrado'];
        }
        
        $sql = "INSERT INTO usuarios (nombre, email, password, company, registration_type, how_heard, newsletter, comment) 
                VALUES ('$nombre', '$email', '$password', '$company', '$registration_type', '$how_heard', $newsletter, '$comment')";
        
        if (mysqli_query($this->conexion, $sql)) {
            return ['success' => true, 'message' => 'Usuario registrado exitosamente'];
        } else {
            return ['success' => false, 'message' => 'Error al registrar usuario: ' . mysqli_error($this->conexion)];
        }
    }
    
    // Iniciar sesión
    public function login($email, $password) {
        $email = mysqli_real_escape_string($this->conexion, $email);
        
        $sql = "SELECT * FROM usuarios WHERE email = '$email'";
        $resultado = mysqli_query($this->conexion, $sql);
        
        if ($resultado && mysqli_num_rows($resultado) > 0) {
            $user = mysqli_fetch_assoc($resultado);
            
            if (password_verify($password, $user['password'])) {
                // Iniciar sesión
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['nombre'];
                $_SESSION['user_email'] = $user['email'];
                
                return ['success' => true, 'message' => 'Inicio de sesión exitoso'];
            } else {
                return ['success' => false, 'message' => 'Contraseña incorrecta'];
            }
        } else {
            return ['success' => false, 'message' => 'Usuario no encontrado'];
        }
    }
    
    // Verificar si un email existe
    private function emailExists($email) {
        $email = mysqli_real_escape_string($this->conexion, $email);
        $sql = "SELECT id FROM usuarios WHERE email = '$email'";
        $resultado = mysqli_query($this->conexion, $sql);
        return mysqli_num_rows($resultado) > 0;
    }
    
    // Cerrar conexión
    public function __destruct() {
        if ($this->conexion) {
            mysqli_close($this->conexion);
        }
    }
}
?>
