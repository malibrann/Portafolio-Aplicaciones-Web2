<?php
/**
 * Script de verificación del sistema
 * Verifica que todos los componentes estén correctamente instalados
 * 
 * Accede a: http://localhost/AplicacionesWeb/replicaPagina/verificar.php
 */

echo "<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Verificación del Sistema - Roux Academy</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 900px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
        h1 { color: #333; }
        .check { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #4CAF50; }
        .error { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #f44336; }
        .warning { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; border-left: 4px solid #ff9800; }
        .success { color: #4CAF50; font-weight: bold; }
        .fail { color: #f44336; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; background: white; margin: 20px 0; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #4CAF50; color: white; }
        .btn { display: inline-block; background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 20px; }
    </style>
</head>
<body>";

echo "<h1>🔍 Verificación del Sistema - Roux Academy</h1>";
echo "<hr>";

$errores = 0;
$advertencias = 0;

// 1. Verificar versión de PHP
echo "<h2>1. Versión de PHP</h2>";
$phpVersion = phpversion();
if (version_compare($phpVersion, '7.0', '>=')) {
    echo "<div class='check'>✅ <span class='success'>PHP $phpVersion</span> - OK</div>";
} else {
    echo "<div class='error'>❌ <span class='fail'>PHP $phpVersion</span> - Se requiere PHP 7.0 o superior</div>";
    $errores++;
}

// 2. Verificar extensiones de PHP
echo "<h2>2. Extensiones de PHP</h2>";
$extensiones = ['mysqli', 'session', 'json'];
foreach ($extensiones as $ext) {
    if (extension_loaded($ext)) {
        echo "<div class='check'>✅ <span class='success'>$ext</span> - Cargada</div>";
    } else {
        echo "<div class='error'>❌ <span class='fail'>$ext</span> - No disponible</div>";
        $errores++;
    }
}

// 3. Verificar archivos principales
echo "<h2>3. Archivos Principales</h2>";
$archivos = [
    'config.php' => 'Configuración',
    'index.php' => 'Enrutador principal',
    '.htaccess' => 'Reescritura de URLs',
    'encabezado.php' => 'Header',
    'pie.php' => 'Footer',
    'Pagina.css' => 'Estilos CSS',
    'models/User.php' => 'Modelo de Usuario',
    'controllers/login_controller.php' => 'Controlador de Login',
    'controllers/register_controller.php' => 'Controlador de Registro',
    'views/home.php' => 'Vista Home',
    'views/login.php' => 'Vista Login',
    'views/register.php' => 'Vista Registro'
];

foreach ($archivos as $archivo => $descripcion) {
    if (file_exists($archivo)) {
        echo "<div class='check'>✅ <span class='success'>$archivo</span> - $descripcion</div>";
    } else {
        echo "<div class='error'>❌ <span class='fail'>$archivo</span> - $descripcion (NO ENCONTRADO)</div>";
        $errores++;
    }
}

// 4. Verificar carpetas
echo "<h2>4. Estructura de Carpetas</h2>";
$carpetas = ['controllers', 'models', 'views', 'images'];
foreach ($carpetas as $carpeta) {
    if (is_dir($carpeta)) {
        echo "<div class='check'>✅ <span class='success'>$carpeta/</span> - Existe</div>";
    } else {
        echo "<div class='error'>❌ <span class='fail'>$carpeta/</span> - No existe</div>";
        $errores++;
    }
}

// 5. Verificar conexión a la base de datos
echo "<h2>5. Conexión a Base de Datos</h2>";
require_once 'config.php';
$conexion = @mysqli_connect(DB_HOST, DB_USER, DB_PASS);

if ($conexion) {
    echo "<div class='check'>✅ <span class='success'>Conexión a MySQL</span> - OK</div>";
    
    // Verificar si existe la base de datos
    $db_exists = mysqli_select_db($conexion, DB_NAME);
    if ($db_exists) {
        echo "<div class='check'>✅ <span class='success'>Base de datos '" . DB_NAME . "'</span> - Existe</div>";
        
        // Verificar tabla usuarios
        $result = @mysqli_query($conexion, "SHOW TABLES LIKE 'usuarios'");
        if ($result && mysqli_num_rows($result) > 0) {
            echo "<div class='check'>✅ <span class='success'>Tabla 'usuarios'</span> - Existe</div>";
            
            // Contar usuarios
            $count_result = mysqli_query($conexion, "SELECT COUNT(*) as total FROM usuarios");
            $count = mysqli_fetch_assoc($count_result);
            echo "<div class='check'>ℹ️ Total de usuarios registrados: <strong>" . $count['total'] . "</strong></div>";
        } else {
            echo "<div class='error'>❌ <span class='fail'>Tabla 'usuarios'</span> - No existe</div>";
            echo "<div class='warning'>⚠️ Ejecuta <a href='install.php'>install.php</a> para crear las tablas</div>";
            $errores++;
        }
    } else {
        echo "<div class='error'>❌ <span class='fail'>Base de datos '" . DB_NAME . "'</span> - No existe</div>";
        echo "<div class='warning'>⚠️ Ejecuta <a href='install.php'>install.php</a> para crear la base de datos</div>";
        $errores++;
    }
    
    mysqli_close($conexion);
} else {
    echo "<div class='error'>❌ <span class='fail'>Conexión a MySQL</span> - Error: " . mysqli_connect_error() . "</div>";
    echo "<div class='warning'>⚠️ Verifica las credenciales en config.php</div>";
    $errores++;
}

// 6. Verificar permisos de escritura (si es necesario)
echo "<h2>6. Permisos del Sistema</h2>";
if (is_writable('.')) {
    echo "<div class='check'>✅ <span class='success'>Permisos de escritura</span> - OK</div>";
} else {
    echo "<div class='warning'>⚠️ <span>Permisos de escritura</span> - Limitados (puede causar problemas)</div>";
    $advertencias++;
}

// Resumen
echo "<hr>";
echo "<h2>📊 Resumen de la Verificación</h2>";

echo "<table>";
echo "<tr><th>Componente</th><th>Estado</th></tr>";
echo "<tr><td>PHP</td><td class='success'>✓</td></tr>";
echo "<tr><td>Extensiones PHP</td><td class='success'>✓</td></tr>";
echo "<tr><td>Archivos</td><td>" . ($errores == 0 ? "<span class='success'>✓</span>" : "<span class='fail'>✗</span>") . "</td></tr>";
echo "<tr><td>Base de Datos</td><td>" . ($errores == 0 ? "<span class='success'>✓</span>" : "<span class='fail'>✗</span>") . "</td></tr>";
echo "</table>";

if ($errores == 0) {
    echo "<div class='check' style='border-left-width: 8px;'>";
    echo "<h3>🎉 ¡Sistema Verificado Correctamente!</h3>";
    echo "<p>Todos los componentes están instalados y configurados correctamente.</p>";
    echo "<a href='index.php' class='btn'>Ir a la Aplicación →</a>";
    echo "</div>";
} else {
    echo "<div class='error' style='border-left-width: 8px;'>";
    echo "<h3>⚠️ Se encontraron $errores error(es)</h3>";
    echo "<p>Por favor, revisa los errores anteriores y corrígelos antes de usar la aplicación.</p>";
    if ($errores > 0) {
        echo "<a href='install.php' class='btn'>Ejecutar Instalador</a>";
    }
    echo "</div>";
}

if ($advertencias > 0) {
    echo "<div class='warning'>";
    echo "<p>ℹ️ Se encontraron $advertencias advertencia(s). La aplicación debería funcionar, pero revisa los detalles.</p>";
    echo "</div>";
}

echo "</body></html>";
?>
