<?php 
$pageTitle = 'Schedule - Roux Academy';
include 'encabezado.php'; 
?>

<div class="contenedor">
    <main>
        <h1>Schedule</h1>
        <p>With over 35 seminars and 60 exhibits at this year's Roux Academy CAC, there is
truly something for every art student. Learn about color, light, and texture; see
spray paint tagging in a new light, as a breath-taking 20 ft high graffiti wall is built
before your very eyes over the course of the week; and rub paint brushes with
some of the most talented artists in the world.</p>

        <h1>Monday, March 7, 2016</h1>
        <h2>Art in Full Color</h2>
        <p>The first day of CAC events and exhibits is kicked off under the theme of Art in Full
Color From a demonstration in graffiti art on a wall of the Rousseau Room, to the
exhibit of colorful glazed modern glassware in the Dover Hall, Art in Full Color will
get CAC started in full swing!</p>

        <h2>Art in Unexpected Places</h2>
        <p><strong>09:30-10:30am: Elizabeth Hall</strong><br>
Watch LaVonne L. LaRue, a Chicago graffiti artist share her love and skill of mural
art on Monday's schedule, as she starts the painting of a 20-foot high wall in the
Rousseau Room of Hotel Contempo, which will be finished at the end of the
conference. Make sure to show up a bit early, as this session will be standing-room
only.</p>

        <h2>Art in Full Bloom</h2>
        <p><strong>11:00am-1pm: Victoria Hall</strong><br>
Drawing and painting flowers may seem like a first-year art student's assignment,
but Constance Smith brings depth, shadows, light, and color to new heights with
his unique technique of painting on canvas with ceramic glaze. This session is sure
to be a hit with mixed media buffs.</p>

        <h2>Still Life</h2>
        <p><strong>2:30-4:00pm: Dennison Hall</strong><br>
Grab your pencils, charcoal, acrylics, watercolors, or whatever painting tools suit
your fancy, and participate in the capturing of various still life settings that are
staged all around Dennison Hall. You won't believe the wealth and depth of
choices.</p>

        <h1>Tuesday March 8, 2016</h1>
        <h2>Water in Art</h2>
        <p>Water in Art is the theme for the second day, as art students from around the world
gather at the Fountain of Intrigue in the gardens of Hotel Contempo to create ice
sculptures, and art lecturers discuss the use of water as an art material, and water
as an art subject.</p>

        <h2>Water in Art Kickoff Session</h2>
        <p><strong>09:30-10:30am: Elizabeth Hall</strong><br>
Jennifer Jerome, a native of New Orleans, whose work has centered around
abstract images that depict flooding and rebuilding, will talk about how the floods
inspired her artistically, and how, despite the sadness of devastation and lives lost,
her work also depicts the hope and togetherness of a community that has
persevered.</p>

        <h2>Ice Sculptures</h2>
        <p><strong>10:30am-1pm: Fountain of Intrigue</strong><br>
Get on your mittens and earmuffs, and join your fellow artists at the Fountain of
Intrigue, in the Hotel Contempo gardens, where the ambient temperature has been
turned down to allow the sculpting of ice into the most mysterious and beautiful of
shapes. Richard Reed will share his secrets for chiseling ice into a shape that your
imagination has envisioned. There is an extra fee of $25 for the rental of the tools
needed to sculpt ice, if you plan to participate. And we hope you do!</p>

        <h2>Deep Sea Wonders</h2>
        <p><strong>2:30-4:00pm: Dennison Hall</strong><br>
Hillary Hewitt Goldwynn-Post has been inspiring deep sea divers to paint what they
experience under water for nearly two decades. Not only does he explain texture,
color, and tools, be he also explains methods for capturing your under sea
explorations in your mind for future expulsion onto canvas.</p>
    </main>

    <aside>
        <h2>Featured Artists</h2>
        <p>Each year, nine individuals are honored as Featured Artists - each being granted
his or her own exhibit hall to display entire collections or themed pieces. Each
Featured Artist has an opportunity to speak at the conference to share his or her
vision, perspective, and techniques with conference attendees.</p>
        
        <a href="<?php echo url('artist'); ?>">View Artist Info &gt;&gt;</a>
    </aside>
</div>

<?php include 'pie.php'; ?>
