<?php 
$pageTitle = 'Artists - Roux Academy';
include 'encabezado.php'; 
?>

<div class="contenedor">
    <main>
        <h1>Featured Artists</h1>
        <p>The Roux Academy's annual conference and exhibit is designed to foster a close-
knit relationship amongst artists at various universities around the world. But sign
up early, as this not-to-miss conference sells out quickly, and the waiting list is long.
In addition, art students are encouraged to send in works from their school
portfolios to be considered for hanging in the CAC exhibit halls, as well as to be
selected as a Featured Artist.</p>

        <h2>Barot Bellingham</h2>
        <p>Barot has just finished his final year at The Royal Academy of Painting and
Sculpture, where he excelled in glass etching paintings and portraiture. Hailed as
one of the most diverse artists of his generation, Barot is equally as skilled with
watercolors as he is with oils.</p>

        <h2>Jonathan G. Ferrar II</h2>
        <p>Labeled as "The Artist to Watch in 2016" by the London Review, Johnathan has
already sold one of the highest priced commissions paid to an art student, ever on
record. The piece, entitled Gratitude Resort, a work in oil and mixed media, was
sold for $750,000.</p>

        <h2>Hillary Hewitt Goldwynn-Post</h2>
        <p>Hillary is a sophomore art sculpture student at New York University, and has
already won all the major international prizes for new sculptors, including the
Divinity Circle, the International Sculptor's Medal, and the Academy of Paris
Award. Hillary's CAC exhibit features paintings that contain only water images
including waves, deep sea, and river.</p>

        <h2>Hassum Harrod</h2>
        <p>The Art College in New Dehli has sponsored Hassum for his entire undergraduate
career at the university, seeing great promise in his contemporary paintings of
landscapes - that use equal parts muted and vibrant tones. Hassum will be
speaking on "The use and absence of color in modern art".</p>

        <h2>Jennifer Jerome</h2>
        <p>A native of New Orleans, much of Jennifer's work has centered around abstract
images that depict flooding and rebuilding, having grown up as a teenager in the
post-flood years. Despite the sadness of devastation and lives lost.</p>

        <h2>LaVonne L. LaRue</h2>
        <p>LaVonne's giant-sized paintings all around Chicago tell the story of love, nature,
and conservation - themes that are central to her heart. LaVonne will share her
love and skill of graffiti art on Monday's schedule, as she starts the painting of a 20-
foot high wall in the Rousseau Room of Hotel Contempo in front of a standing-
room only audience in Art in Unexpected Places.</p>

        <h2>Constance Olivia Smith</h2>
        <p>Constance received the Fullerton-Brighton-Norwell Award for Modern Art for her
mixed-media image of a tree of life, with jewel-adorned branches depicting the
arms of humanity, and precious gemstone-decorated leaves representing the
spouting buds of togetherness.</p>

        <h2>Riley Rudolph Rewington</h2>
        <p>A first-year student at the Roux Academy of Art, Media, and Design, Riley is
already changing the face of modern art at the university. Riley's exquisite abstract
pieces have no intention of ever being understood, but instead beg the viewer to
dream, create, pretend, and envision with their mind's eye. Riley will be speaking
on the "Art of Abstract" during Thursday's schedule.</p>

        <h2>Xhou Ta</h2>
        <p>A senior at the China International Art University, Xhou has become well-known for
his miniature sculptures, often the size of a rice granule, that are displayed by rear
projection of microscope images on canvas. Xhou will discuss the art and science
behind his incredibly detailed works of art.</p>
    </main>

    <aside>
        <h2>The Art</h2>
        <p>This year's art pieces will inspire thought, conversation, imagination, and even
criticism, as modern art often does. From critically-acclaimed works created by our
Featured Artists, to a vast assortment of works by talented art students in schools
across the world.</p>
    </aside>
</div>

<?php include 'pie.php'; ?>
