<?php 
$pageTitle = 'Home - Roux Academy';
include 'encabezado.php'; 
?>

<div class="contenedor">
    <main>
        <?php if (isset($_SESSION['success'])): ?>
            <div style="background: #4CAF50; color: white; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div style="background: #f44336; color: white; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>
        
        <h1>About the event</h1>
        <p>The Roux Academy's annual conference and exhibit is designed to foster a close-
knit relationship amongst artists at various universities around the world. But sign
up early, as this not-to-miss conference sells out quickly, and the waiting list is long.
In addition, art students are encouraged to send in works from their school
portfolios to be considered for hanging in the CAC exhibit halls, as well as to be
selected as a Featured Artist.</p>

        <h1>Featured artist</h1>
        <p>The Roux Academy selects approximately 200 distinct pieces of contemporary art
for display in their collective exhibit. Nine individuals are granted his or her own
exhibit hall to display entire collections or themed pieces. Each Featured Artist has
an opportunity to speak at the conference to share his or her vision, perspective,
and techniques with conference attendees.</p>

        <div class="imagenes">
            <img src="<?php echo url('images/artists/Barot_Bellingham_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Constance_Smith_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Hassum_Harrod_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Hillary_Goldwynn_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Jennifer_Jerome_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Jonathan_Ferrar_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/LaVonne_LaRue_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Riley_Rewington_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Xhou_Ta_tn.jpg'); ?>">
        </div>
        <a class="artist-link" href="<?php echo url('artist'); ?>">View Artist Info &gt;&gt;</a>

        <h1>The venue</h1>
        <h2>Hotel contempo</h2>
        <div class="hotel">
            <img src="<?php echo url('images/hotel_contempo.jpg'); ?>" alt="hotel">
            <div class="hotel-text">
                CAC speaking events and gallery exhibits take place inside Hotel Contempo, at
                309 1st Avenue, in Downtown Seattle. Just a walk to the Space Needle, and a
                sampling of restaurants and shopping makes the venue a much sought-after
                location for conferences, year after year.
                Hotel Contempo is the perfect spot for a gathering of modern artists. Not only are
                the conference rooms and halls decked with breathtaking contemporary art and
                sculptures, but the individual rooms are as unique as the renowned artists who
                were commissioned to decorate them. From the Ross Monroe Purple suite filled
                wall to wall with paintings to the Tess Lessinger Sculpted Universe suite, with
                dozens of original sculptures, visitors are sure to be intrigued and comforted during
                their stay at Hotel Contempo.
            </div>
        </div>
    </main>

    <aside>
        <h2>Coming to the event?</h2>
        <h3>check out our mobile site</h3>
        <p>Our mobile site contains schedules, and exhibit/ artist details, accessible simply by
scanning QR codes located all around the venue exhibit halls.</p>
        <img src="<?php echo url('images/iphone.png'); ?>" alt="mobile">
        <a href="#">Roux Mobile &gt;&gt;</a>

        <h2>Schedule</h2>
        <h3>Monday</h3>
        <p>The first day of CAC events is kicked off under the theme of Art in Full Color. From
a demonstration in graffiti art on a wall of the Rousseau Room, to the exhibit of
colorful glazed modern glassware in the Dover Hall.</p>

        <h3>Tuesday</h3>
        <p>Water in Art is the theme for the second day, as art students gather at the Fountain
of Intrigue to create ice sculptures, and art lecturers discuss the use of water as an
art material, and water as an art subject.</p>

        <a href="<?php echo url('schedule'); ?>">Full Schedule &gt;&gt;</a>
    </aside>
</div>

<?php include 'pie.php'; ?>
