<?php 
$pageTitle = 'Register - Roux Academy';
include 'encabezado.php'; 
?>

<div class="contenedor">
    <main>
        <h1>Register</h1>
        <p>To attend the Roux Academy 2016 Contemporary Art Conference, please complete
the information below.</p>

        <?php if (isset($_SESSION['error'])): ?>
            <div style="background: #f44336; color: white; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo url('register-submit'); ?>">
            <h2>Personal Info</h2>
            <label for="fname">Name *</label>
            <input type="text" id="fname" name="fname" placeholder="First Name" required>
            
            <label for="cname">Company Name</label>
            <input type="text" id="cname" name="cname">
            
            <label for="email">Email *</label>
            <input type="email" id="email" name="email" required>
            
            <label for="password">Password *</label>
            <input type="password" id="password" name="password" required>
            
            <h2>Registration Type</h2>
            <label for="regtype">Question</label>
            <select id="regtype" name="regtype">
                <option>Choose</option>
                <option value="Student">Student</option>
                <option value="Professional">Professional</option>
            </select>
            
            <label for="comment">Comment</label>
            <textarea id="comment" name="comment" rows="4"></textarea>
            
            <label>
                <input type="checkbox" name="newsletter" value="1"> Subscribe to our mailing list?
            </label>
            
            <label for="howheard">How did you hear about us?</label>
            <select id="howheard" name="howheard">
                <option>Choose</option>
                <option value="Google">Google</option>
                <option value="A Friend">A Friend</option>
                <option value="Facebook">Facebook</option>
                <option value="Twitter">Twitter</option>
            </select>
            
            <button type="submit">Register</button>
        </form>
    </main>

    <aside>
        <h2>Featured Artists</h2>
        <p>Each year, nine individuals are honored as Featured Artists - each being granted
his or her own exhibit hall to display entire collections or themed pieces. Each
Featured Artist has an opportunity to speak at the conference to share his or her
vision, perspective, and techniques with conference attendees.</p>
        
        <div class="imagenes">
            <img src="<?php echo url('images/artists/Barot_Bellingham_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Constance_Smith_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Hassum_Harrod_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Hillary_Goldwynn_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Jennifer_Jerome_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Jonathan_Ferrar_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/LaVonne_LaRue_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Riley_Rewington_tn.jpg'); ?>">
            <img src="<?php echo url('images/artists/Xhou_Ta_tn.jpg'); ?>">
        </div>
        <a href="<?php echo url('artist'); ?>">Artist Info &gt;&gt;</a>
    </aside>
</div>

<?php include 'pie.php'; ?>
