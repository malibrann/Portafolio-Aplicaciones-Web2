<?php 
$pageTitle = 'Login - Roux Academy';
include 'encabezado.php'; 
?>

<div class="contenedor">
    <main>
        <h1>Login</h1>
        <p>Please enter your credentials to access your account.</p>

        <?php if (isset($_SESSION['success'])): ?>
            <div style="background: #4CAF50; color: white; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div style="background: #f44336; color: white; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo url('login'); ?>">
            <label for="email">Email *</label>
            <input type="email" id="email" name="email" required>
            
            <label for="password">Password *</label>
            <input type="password" id="password" name="password" required>
            
            <button type="submit">Login</button>
        </form>

        <p style="margin-top: 2rem;">
            Don't have an account? <a href="<?php echo url('register'); ?>" style="color: blue; font-weight: bold;">Register here</a>
        </p>

        <div style="background: #e3f2fd; padding: 1rem; margin-top: 2rem; border-radius: 5px; border-left: 4px solid #2196F3;">
            <h3 style="margin-top: 0;">Demo Account</h3>
            <p><strong>Email:</strong> demo@example.com</p>
            <p><strong>Password:</strong> password123</p>
        </div>
    </main>

    <aside>
        <h2>Why Register?</h2>
        <p>By creating an account, you'll be able to:</p>
        <ul style="line-height: 2;">
            <li>Save your registration details</li>
            <li>Access exclusive content</li>
            <li>Receive conference updates</li>
            <li>Connect with other attendees</li>
        </ul>

        <h2>Need Help?</h2>
        <p>If you're having trouble logging in or registering, please contact our support team.</p>
        <a href="#">Contact Support &gt;&gt;</a>
    </aside>
</div>

<?php include 'pie.php'; ?>
